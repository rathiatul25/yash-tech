import {EMPLOYEE_LIST, EMPLOYEE_SHOW, EMPLOYEE_SEARCH} from "../actions/types";
import _ from 'lodash';

export default (state = {}, action) => {
    switch (action.type){
        case EMPLOYEE_LIST:
            return { ...state, ..._.mapKeys(action.payload, 'id')};
        case EMPLOYEE_SHOW:
        	//console.log(action.payload.id)
        	return { ...state, [action.payload.id]:action.payload};
        case EMPLOYEE_SEARCH:
        	return {...state={}, ..._.mapKeys(action.payload, 'id')};
        default:
            return state;
    }
}
