import instance from '../apis/instance';
import {EMPLOYEE_LIST, EMPLOYEE_SHOW, EMPLOYEE_SEARCH} from "./types";
import qs from 'qs';

export const fetchEmployee = () => async(dispatch) => {
    const response = await instance.get('/employees');
    dispatch({type:EMPLOYEE_LIST, payload:response.data })
};

export const showEmployee = (id) => async(dispatch) => {
    const response = await instance.get(`/employees/${id}`);
    dispatch({type:EMPLOYEE_SHOW, payload:response.data })
};

export const searchEmployee = (tech,skill,location,experience) => async(dispatch) => {
	const response = await instance.get(`/employees?experience_gte=0&experience_lte=${experience}`,{
		params:{
			technologies_like: tech,
			skills_like:skill,
			base_location_like:location,
		},
		  paramsSerializer: params => {
		    return qs.stringify(params)
		  }
	});
    dispatch({type:EMPLOYEE_SEARCH, payload:response.data })
}