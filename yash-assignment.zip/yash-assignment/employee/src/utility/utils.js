export const numberPad = (n) => {
    return (n < 10) ? ("0" + n) : n;
}

export const technologies = [
  { value: 'Java', label: 'Java' },
  { value: 'React', label: 'React' },
  { value: 'Photoshop', label: 'Photoshop' },
  { value: 'XD', label: 'XD' },
  { value: 'Php', label: 'Php' }
]

export const skills = [
  { value: 'Java Developer', label: 'Java Developer' },
  { value: 'UX Developer', label: 'UX Developer' },
  { value: 'UI Developer', label: 'UI Developer' },
  { value: 'React Developer', label: 'React Developer' },
  { value: 'Php Developer', label: 'Php Developer' }
]

export const locations = [
  {value: 'Indore', label:'Indore'},
  {value: 'Pune', label:'Pune'},
  {value: 'Mumbai', label:'Mumbai'}
]