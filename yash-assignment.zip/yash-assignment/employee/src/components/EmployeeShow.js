import React,{ Component }  from 'react';
import { connect } from 'react-redux';
import { Modal,Form,Button,Row,Col,Container } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { showEmployee } from '../actions';

class EmployeeShow extends Component {
  state = {
    show: false
  }

  handleClose = () => {
    this.setState({show:false});
  }

  handleShow = () => {
    this.setState({show:true});
    this.props.showEmployee(this.props.id);
  }

  render(){
   
    
    //console.log(this.props.employee);
    let {name,skills,open_to_relocate,designation,availability,technologies,base_locatuion} = this.props.employee;
    return (
      <div>
        <Button variant="primary" onClick={this.handleShow}>
          Details
        </Button>

        <Modal show={this.state.show} onHide={this.handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Employee Details</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Container>
              <Row>
                <Col><p>Name</p><strong>{name}</strong></Col>
                <Col><p>Skill</p><strong>{skills.toString()}</strong></Col>
                <Col><p>Open to Relocate</p><strong>{open_to_relocate}</strong></Col>
              </Row>
              <Row>
                <Col><p>Designation</p><strong>{designation}</strong></Col>
                <Col><p>Availability</p><strong>{availability}</strong></Col>
              </Row>
              <Row>
                <Col><p>Technologies</p><strong>{technologies.toString()}</strong></Col>
                <Col><p>Base Location</p><strong>{base_locatuion}</strong></Col>
              </Row>
              <Row>
                <Col>
                  <Form.Group>
                    <Form.Label>Message</Form.Label>
                    <Form.Control as="textarea" rows="3" />
                  </Form.Group>
                </Col>
              </Row>  
              
            </Container>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.handleClose}>
              Cancel
            </Button>
            <Button variant="primary" onClick={this.handleClose}>
              Done
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    );
  }  
}

const mapStateToProps = (state,ownProps) => {
  return {employee: state.employee[ownProps.id]}
}

export default connect(mapStateToProps,{showEmployee})(EmployeeShow);