import React from 'react';
import { Nav, Navbar, Form, FormControl, Button } from 'react-bootstrap';
const NavBar = () => {
	return (
		<Navbar bg="dark" variant="dark">
		    <Navbar.Brand href="#home">Employee</Navbar.Brand>
		    <Nav className="mr-auto">
		      <Nav.Link href="#home">Dashboard</Nav.Link>
		      <Nav.Link href="#features">Relocate</Nav.Link>
		      <Nav.Link href="#pricing">Directory</Nav.Link>
		      <Nav.Link href="#pricing">Projects</Nav.Link>
		      <Nav.Link href="#pricing">Technology</Nav.Link>
		    </Nav>
		    <Form inline>
		      <FormControl type="text" placeholder="Search" className="mr-sm-2" />
		      <Button>Search</Button>
		    </Form>
	    </Navbar>
	)
}

export default NavBar;