import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Card, Form, Button, Container, Table, Col, Row  } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { fetchEmployee, searchEmployee } from '../actions';
import EmployeeShow from './EmployeeShow';
import MultiSelectComponent from './MultiSelectComponent';
import {numberPad, technologies, skills, locations } from '../utility/utils';
import NavBar from './NavBar';

class EmployeeList extends Component {
	state = {
		technologies:[],
		skills:[],
		locations:[],
		experience:'20'
	}

	componentDidMount() {
		this.props.fetchEmployee();
	}
	
	renderList() {
		return this.props.employees.map(employee => {
			return (
				<tr key={employee.id}>
					<td><input type='checkbox' /></td>
					<td>{employee.name}</td>
					<td>{employee.designation}</td>
					<td>{employee.technologies.toString()}</td>
					<td>{employee.skills.toString()}</td>
					<td>{employee.experience}</td>
					<td>{employee.base_location}</td>
					<td>{employee.open_to_relocate}</td>
					<td><EmployeeShow id={employee.id} /></td>
				</tr>
			);
		});
	}

	onSearch = (e) => {
		e.preventDefault();
		let technologies = this.state.technologies;
		let skills = this.state.skills;
		let locations = this.state.locations;
		let experience = this.state.experience;
		this.props.searchEmployee(technologies, skills, locations, experience);
	}

	onCancel = () => {
		let technologies = [];
		let skills = [];
		let locations = [];
		let experience = 20;
		this.props.searchEmployee(technologies, skills, locations, experience);
	}

	onTechnologyChange = (technologies) => { this.setState({technologies}) }

	onSkillChange = (skills) => { this.setState({skills}) }

	onLocationChange = (locations) => { this.setState({locations}) }

	onExperienceChange = (experience) => { this.setState({experience:numberPad(experience)}) }

	render() {
		if(!this.props.employees){	
			return <div>loading...</div>
		}
		return (
			<div>
				<NavBar />
			    <Container>
				    <Row>
				  		<Col>
						    <Card style={{ width: '18rem' }}>
			  					<Card.Body>
						    	<h4>Filter By</h4>
						    	
						    	<p>Technology</p>
						    	<MultiSelectComponent 
						    		optionValues={technologies} 
						    		onChange={this.onTechnologyChange}
						    	/>
						    	<p>Skills</p>
						    	<MultiSelectComponent 
						    		optionValues={skills} 
						    		onChange={this.onSkillChange}
						    	/>
						    	<p>Total Experience(0-20)
						    	<Form.Control type="range" min={0} max={20} value={this.state.experience} onChange={(e) => this.onExperienceChange(e.target.value)} />
						    	</p>

						    	<p>locations</p>
						    	<MultiSelectComponent 
						    		optionValues={locations} 
						    		onChange={this.onLocationChange}
						    	/>
						    	<Button variant="primary" onClick={this.onCancel}>Cancel</Button>	
						    	<Button variant="primary" onClick={this.onSearch}>Done</Button>
						    	</Card.Body>
							</Card>
			   
							<Card>
							  <Card.Body>
							  	<Card.Text>Employee List</Card.Text>
							  	<Button>Add</Button>	
						    	<Button>Delete</Button>
						    	<Card.Title>Total: {this.props.employees.length}</Card.Title>
									<Table>
										<thead>
										<tr>
											<th><input type='checkbox' /></th>
											<th>Name</th>
											<th>Designation</th>
											<th>Technologies</th>
											<th>Skill</th>
											<th>Experience</th>
											<th>Base Location</th>
											<th>Open Relocate</th>
											<th>Action</th>
										</tr>
										</thead>
										<tbody>
											{this.renderList()}
										</tbody>
									</Table>
							  </Card.Body>
							</Card>
						</Col>
					</Row>
				</Container>
			</div>
		)
	}
}

const mapStateToProps = (state) => {
	return {
		employees: Object.values(state.employee)
	};
}
export default connect(mapStateToProps,{fetchEmployee, searchEmployee})(EmployeeList);