import React from 'react';
import Select from 'react-select';
import _ from 'lodash';

const MultiSelectComponent = (props) => {
 
  function onChange(val){
    let values = _.map(val, 'value');
    props.onChange(values);  
  }

  return(
    <div>
    <Select
      closeMenuOnSelect={false}
      isMulti
      options={props.optionValues}
      onChange={onChange}
    />
    </div>
  )
}

export default MultiSelectComponent;