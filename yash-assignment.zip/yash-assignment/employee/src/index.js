import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore,applyMiddleware } from 'redux';
import reduxThunk from 'redux-thunk';
import './index.css';
//import getMuiTheme from 'material-ui/styles/getMuiTheme';
//import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import reducers from './reducers';
import App from './App';

const store = createStore(reducers,applyMiddleware(reduxThunk));

/*ReactDOM.render(
  <Provider store={store}>
  	<MuiThemeProvider muiTheme={getMuiTheme()}>
    	<App />
    </MuiThemeProvider>
  </Provider>   
  ,
  document.getElementById('root')
);*/
ReactDOM.render(
  <Provider store={store}>
   	<App />
  </Provider>   
  ,
  document.getElementById('root')
);



